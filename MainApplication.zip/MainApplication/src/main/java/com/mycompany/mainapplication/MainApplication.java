/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.mainapplication;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import com.mycompany.mainapplication.GPACalculator;
/**
 *
 * @author zheey
 */
public class MainApplication {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Welcome to the GPA Calculator!");

        List<Course> courses = new ArrayList<>();
        GPACalculator gpaCalculator = new GPACalculator();

        // Accept course details from the user
        while (true) {
            Course course = CourseInputReader.acceptCourseDetails(scanner);
            if (course == null) {
                break;
            }
            courses.add(course);
        }

        // Display course details in tabular form
        TablePrinter.displayTable(courses); 

        // Calculate and display GPA
        double gpa = gpaCalculator.calculateGPA(courses);
        System.out.printf("Your GPA is = %.2f  to 2 decimal places.\n", gpa);

        scanner.close();
    }
}

